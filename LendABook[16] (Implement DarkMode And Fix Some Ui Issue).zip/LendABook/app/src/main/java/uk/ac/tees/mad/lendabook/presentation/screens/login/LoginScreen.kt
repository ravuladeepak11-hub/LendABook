package uk.ac.tees.mad.lendabook.presentation.screens.login

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.navigation.NavHostController
import uk.ac.tees.mad.lendabook.R
import uk.ac.tees.mad.lendabook.domain.common.UiState
import uk.ac.tees.mad.lendabook.presentation.components.AppIcon
import uk.ac.tees.mad.lendabook.presentation.components.AppTitleText
import uk.ac.tees.mad.lendabook.presentation.components.textfields.EmailTextField
import uk.ac.tees.mad.lendabook.presentation.components.textfields.PasswordTextField
import uk.ac.tees.mad.lendabook.presentation.navigation.CreateAccountRoute
import uk.ac.tees.mad.lendabook.presentation.navigation.BrowseBookRoute
import uk.ac.tees.mad.lendabook.utils.Dimen
import uk.ac.tees.mad.lendabook.utils.showToast

@Composable
fun LoginScreen(navHostController: NavHostController) {

    val viewModel: LoginViewModel = hiltViewModel()
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    //For UiState
    LaunchedEffect(uiState) {
        when (uiState) {
            is UiState.Error -> {
                val errorMessage = (uiState as UiState.Error).message
                context.showToast(errorMessage)
                viewModel.restUiState()
            }

            is UiState.Success -> {
                val successMessage = (uiState as UiState.Success).message
                context.showToast(successMessage)
                viewModel.restUiState()
            }

            else -> Unit
        }
    }

    //For Navigation
    LaunchedEffect(Unit) {
        viewModel.loginNavigation.collect { navigationEvent ->
            when (navigationEvent) {
                LoginNavigation.Forget -> {

                }

                LoginNavigation.Home -> {
                    navHostController.navigate(BrowseBookRoute)
                }

                LoginNavigation.CreateAccount -> {
                    navHostController.navigate(CreateAccountRoute)
                }
            }
        }
    }

    val gradientBackground = listOf(
        MaterialTheme.colorScheme.surface,
        MaterialTheme.colorScheme.background,
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(gradientBackground)),
    ) {
        LoginContent(viewModel, uiState)
    }

}

@Composable
fun LoginContent(viewModel: LoginViewModel, uiState: UiState) {

    val loginUiState by viewModel.loginUiState.collectAsState()
    val focusManager = LocalFocusManager.current

    Column(
        modifier = Modifier
            .statusBarsPadding()
            .padding(horizontal = Dimen.PaddingMedium),
        verticalArrangement = Arrangement.Center
    )
    {
        AppIcon(
            iconSize = 48.dp,
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        )
        Spacer(modifier = Modifier.height(Dimen.SpacerExtraLarge))
        Column() {
            AppTitleText(
                title = stringResource(id = R.string.welcome_back)
            )
            Spacer(modifier = Modifier.height(Dimen.SpacerMedium))
            EmailTextField(
                value = loginUiState.email,
                onValueChange = { newEmail ->
                    viewModel.onEvent(LoginUiEvent.EmailChanged(newEmail))
                },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(Dimen.SpacerSmall))
            PasswordTextField(
                value = loginUiState.password,
                onValueChange = { newPassword ->
                    viewModel.onEvent(LoginUiEvent.PasswordChange(newPassword))
                },
                modifier = Modifier.fillMaxWidth(),
                keyboardActions = KeyboardActions(
                    onDone = {
                        focusManager.clearFocus()
                    }
                )
            )
            Spacer(modifier = Modifier.height(Dimen.SpacerMedium))
            Button(
                onClick = {
                    viewModel.onEvent(LoginUiEvent.LoginClicked)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                AnimatedContent(
                    targetState = (uiState is UiState.Loading)
                ) { loading ->
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(text = stringResource(R.string.login))
                    }
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(text = stringResource(id = R.string.dont_have_account))
            }
            Button(
                onClick = {
                    viewModel.onEvent(LoginUiEvent.CreateClicked)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
            ) {
                Text(text = stringResource(R.string.create_account))
            }
            Spacer(modifier = Modifier.height(Dimen.SpacerMedium))
        }

    }
}


@Preview(showBackground = true, name = "LendABook – Login Screen")
@Composable
fun LoginScreenPreview() {
    val gradientBackground = listOf(
        MaterialTheme.colorScheme.surface,
        MaterialTheme.colorScheme.background
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(gradientBackground))
    ) {
        Column(
            modifier = Modifier
                .statusBarsPadding()
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // App Icon (Placeholder)
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("Book", fontSize = 32.sp, color = Color.White)
            }

            Spacer(modifier = Modifier.height(48.dp))

            Text(
                text = "Welcome Back!",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(32.dp))

            EmailTextField(
                value = "john.doe@example.com",
                onValueChange = {},
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            PasswordTextField(
                value = "••••••••",
                onValueChange = {},
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {},
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("Login", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.weight(1f))

            Text(
                text = "Don't have an account?",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {},
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("Create Account")
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}